"""Local dry-run and explicitly gated full-run entry point."""
from __future__ import annotations

import argparse
import asyncio
import json
import logging
from pathlib import Path

from .cache import SQLiteCache
from .config import Config
from .export import write_outputs
from .fetcher import quiet_scrapling_logs
from .input import iter_input
from .pipeline import process_records, representative_rows


async def _run(args) -> None:
    config = Config(concurrency=args.concurrency, max_evidence_pages=args.max_evidence_pages,
                    use_dynamic=args.dynamic, use_stealth=args.stealth, use_proxy=bool(args.proxy_url))
    if args.full_run:
        records = list(iter_input(args.input, args.organization_column, args.domain_column))
    else:
        if args.sample_size <= 0:
            raise ValueError("Sample size must be a positive integer")
        records = representative_rows(args.input, args.sample_size,
                                      args.organization_column, args.domain_column,
                                      seed=args.seed)
    cache = SQLiteCache(args.cache, config.cache_ttl_seconds)
    try:
        output, info = await process_records(records, config, cache, dry_run=not args.full_run,
                                              external_evidence_file=args.external_evidence,
                                              search_ambiguous=args.search_ambiguous,
                                              proxy_url=args.proxy_url, fetch_domains=not args.offline,
                                              batch_domains=args.batch_domains,
                                              max_external_searches=args.max_external_searches)
    finally:
        cache.close()
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    summary = write_outputs(output, output_dir / "results.csv", output_dir / "review.csv",
                            output_dir / "evidence.jsonl", output_dir / "summary.json",
                            info["unique_domains"])
    summary["network_healthy"] = info["network_healthy"]
    summary["dry_run"] = not args.full_run
    (output_dir / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps(summary, indent=2))


def main() -> None:
    parser = argparse.ArgumentParser(description="Evidence-based domain/company verification")
    parser.add_argument("--input", default="Domains List_V2.xlsx")
    parser.add_argument("--output-dir", default="verifier/dry_run_output")
    parser.add_argument("--cache", default="verifier/production_cache.sqlite")
    parser.add_argument("--organization-column")
    parser.add_argument("--domain-column")
    parser.add_argument("--sample-size", type=int, default=75)
    parser.add_argument("--seed", type=int, default=42, help="deterministic sampling random seed")
    parser.add_argument("--batch-domains", type=int, default=50)
    parser.add_argument("--full-run", action="store_true", help="explicitly process the complete input")
    parser.add_argument("--concurrency", type=int, default=100)
    parser.add_argument("--max-evidence-pages", type=int, default=4)
    parser.add_argument("--dynamic", action="store_true")
    parser.add_argument("--stealth", action="store_true")
    parser.add_argument("--proxy-url")
    parser.add_argument("--external-evidence", help="JSONL of fetched, reviewed authoritative sources")
    parser.add_argument("--search-ambiguous", action="store_true", help="search the web (free Bing) for sources on pairs without strong proof")
    parser.add_argument("--max-external-searches", type=int, default=100)
    parser.add_argument("--offline", action="store_true", help="inspect sample/output using cached evidence only")
    args = parser.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    quiet_scrapling_logs(logging.WARNING)
    asyncio.run(_run(args))


if __name__ == "__main__":
    main()
